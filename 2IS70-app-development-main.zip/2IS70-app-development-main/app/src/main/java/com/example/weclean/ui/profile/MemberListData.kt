package com.example.weclean.ui.profile

class MemberListData(
    val name: String,
    val id: String,
    val isAdmin: Boolean)