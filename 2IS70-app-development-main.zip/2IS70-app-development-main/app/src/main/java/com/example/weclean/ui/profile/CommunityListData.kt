package com.example.weclean.ui.profile

class CommunityListData(
    var name: String,
    var id: String,
    var userIsAdmin: Boolean) {

}
