package com.example.weclean.ui.profile

enum class ProfileViewStatus {
    PROFILE,
    PROFILE_EDIT,
    COMMUNITY_CREATE,
    COMMUNITIES_LIST,
    COMMUNITY_MANAGE
}