package com.example.weclean.ui.map

enum class MapViewStatus {
    Map,
    LitteringDetails
}